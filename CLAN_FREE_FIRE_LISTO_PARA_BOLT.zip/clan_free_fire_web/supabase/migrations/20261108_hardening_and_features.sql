-- Ejecutar DESPUÉS de schema.sql en un proyecto Supabase nuevo.
-- También sirve como actualización para la primera versión del esquema.
create extension if not exists pgcrypto;

-- Evita exponer correos electrónicos mediante el SELECT de perfiles.
alter table public.profiles drop column if exists email;
create unique index if not exists profiles_username_lower_unique on public.profiles (lower(username));

-- Reemplaza el trigger de alta: username de respaldo siempre <= 20 caracteres.
create or replace function public.on_user_created() returns trigger
language plpgsql security definer set search_path=public as $$
declare nick text; fallback_nick text;
begin
 nick := left(regexp_replace(coalesce(nullif(new.raw_user_meta_data->>'username',''), split_part(coalesce(new.email,'jugador'),'@',1)), '[^[:alnum:]_]', '', 'g'),20);
 if char_length(nick)<3 then nick := 'jugador'; end if;
 fallback_nick := left(nick,14)||'_'||substr(replace(new.id::text,'-',''),1,5);
 insert into public.profiles(id,username) values(new.id,nick);
 insert into public.user_roles(user_id,role) values(new.id,'member') on conflict(user_id) do nothing;
 insert into public.chat_activity(user_id) values(new.id) on conflict(user_id) do nothing;
 insert into public.achievement_unlocks(user_id,code) values(new.id,'first_login') on conflict do nothing;
 return new;
exception when unique_violation then
 insert into public.profiles(id,username) values(new.id,fallback_nick);
 insert into public.user_roles(user_id,role) values(new.id,'member') on conflict(user_id) do nothing;
 insert into public.chat_activity(user_id) values(new.id) on conflict(user_id) do nothing;
 insert into public.achievement_unlocks(user_id,code) values(new.id,'first_login') on conflict do nothing;
 return new;
end $$;

-- Políticas con permisos mínimos. Las consultas del frontend nunca leen email.
drop policy if exists "profiles visible to clan" on public.profiles;
create policy "profiles visible to clan" on public.profiles for select to authenticated
 using (id=auth.uid() or public.is_member() or public.has_admin_access());
drop policy if exists "own profile edit" on public.profiles;
create policy "own profile edit" on public.profiles for update to authenticated
 using(id=auth.uid()) with check(id=auth.uid());
drop policy if exists "roles readable to signed users" on public.user_roles;
create policy "roles visible to self and admins" on public.user_roles for select to authenticated
 using(user_id=auth.uid() or public.has_admin_access());

-- Solo se actualizan campos públicos del perfil. status/joined_at quedan bajo RPC admin.
create or replace function public.guard_profile_update() returns trigger
language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is not null and not public.has_admin_access() then
   if new.status is distinct from old.status or new.joined_at is distinct from old.joined_at or new.id is distinct from old.id then
     raise exception 'No puedes modificar el estado del clan.';
   end if;
 end if;
 if char_length(new.username)<3 or char_length(new.username)>20 then raise exception 'El nombre debe tener entre 3 y 20 caracteres.'; end if;
 return new;
end $$;

-- Tiempo de actividad: el servidor añade como máximo 60 segundos por llamada y exige
-- 50 segundos entre registros. Solo se registra si el usuario está aceptado.
create table if not exists public.chat_heartbeats(
 user_id uuid primary key references auth.users(id) on delete cascade,
 last_seen_at timestamptz not null default now()
);
alter table public.chat_heartbeats enable row level security;
create policy "heartbeat own read" on public.chat_heartbeats for select to authenticated using(user_id=auth.uid());
grant select on public.chat_heartbeats to authenticated;
create or replace function public.record_chat_heartbeat() returns void
language plpgsql security definer set search_path=public as $$
declare previous timestamptz;
begin
 if auth.uid() is null or not public.is_member() then raise exception 'Solo miembros aceptados.'; end if;
 insert into public.chat_heartbeats(user_id,last_seen_at) values(auth.uid(),now())
 on conflict(user_id) do nothing;
 select last_seen_at into previous from public.chat_heartbeats where user_id=auth.uid() for update;
 if previous < now()-interval '50 seconds' then
   update public.chat_activity set seconds=seconds+60,updated_at=now() where user_id=auth.uid();
   update public.chat_heartbeats set last_seen_at=now() where user_id=auth.uid();
 end if;
 insert into public.achievement_unlocks(user_id,code)
 select auth.uid(),code from (values('chat_5h',18000),('chat_10h',36000),('chat_100h',360000)) v(code,threshold)
 where (select seconds from public.chat_activity where user_id=auth.uid())>=threshold
 on conflict(user_id,code) do nothing;
end $$;
grant execute on function public.record_chat_heartbeat() to authenticated;

-- Acciones administrativas de escuadras: nunca se confía en el rol enviado por el cliente.
create or replace function public.admin_remove_squad_member(p_squad_id uuid,p_user_id uuid) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.has_admin_access() then raise exception 'Sin permisos.'; end if;
 delete from public.squad_members where squad_id=p_squad_id and user_id=p_user_id;
 if not found then raise exception 'Integrante no encontrado en esa escuadra.'; end if;
end $$;
create or replace function public.admin_delete_squad(p_squad_id uuid) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.has_admin_access() then raise exception 'Sin permisos.'; end if;
 delete from public.squads where id=p_squad_id;
 if not found then raise exception 'Escuadra no encontrada.'; end if;
end $$;

-- El owner puede promover/degradar administradores, no crear otro owner.
create or replace function public.set_member_role(p_user_id uuid,p_role public.clan_role) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.is_owner() then raise exception 'Solo el propietario puede cambiar roles.'; end if;
 if p_role not in ('member','admin') then raise exception 'Rol inválido.'; end if;
 if p_user_id=auth.uid() then raise exception 'No puedes cambiar tu propio rol.'; end if;
 update public.user_roles set role=p_role where user_id=p_user_id;
 if not found then raise exception 'Usuario no encontrado.'; end if;
end $$;
grant execute on function public.admin_remove_squad_member(uuid,uuid), public.admin_delete_squad(uuid), public.set_member_role(uuid,public.clan_role) to authenticated;

-- Permite el realtime del chat sin abrir escrituras a usuarios no miembros.
do $$ begin
 alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null; when undefined_object then null; end $$;

create or replace view public.achievements_view as
select p.id as user_id, a.code,
 case when a.code='first_login' then 1
      when a.code='clan_100d' then greatest(0,extract(epoch from (now()-coalesce(p.joined_at,now())))/86400)::int
      else coalesce(c.seconds,0)::numeric/3600 end as progress,
 case when a.code='first_login' then true
      when a.code='clan_100d' then p.joined_at is not null and now()-p.joined_at>=interval '100 days'
      when a.code='chat_5h' then coalesce(c.seconds,0)>=18000
      when a.code='chat_10h' then coalesce(c.seconds,0)>=36000
      when a.code='chat_100h' then coalesce(c.seconds,0)>=360000 else false end as completed,
 case when a.code='clan_100d' and p.joined_at is not null and now()-p.joined_at>=interval '100 days'
      then coalesce(u.unlocked_at,p.joined_at+interval '100 days') else u.unlocked_at end as unlocked_at
from public.profiles p
cross join (values('first_login'),('chat_5h'),('chat_10h'),('chat_100h'),('clan_100d')) a(code)
left join public.chat_activity c on c.user_id=p.id
left join public.achievement_unlocks u on u.user_id=p.id and u.code=a.code
where p.id=auth.uid() or public.has_admin_access();
grant select on public.achievements_view to authenticated;


create or replace function public.admin_edit_profile(p_user_id uuid,p_username text,p_instagram text,p_clash text,p_player_id text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.has_admin_access() then raise exception 'Sin permisos.'; end if;
 if char_length(trim(p_username))<3 or char_length(trim(p_username))>20 then raise exception 'El nombre debe tener entre 3 y 20 caracteres.'; end if;
 update public.profiles set username=trim(p_username),instagram=nullif(trim(p_instagram),''),clash=nullif(trim(p_clash),''),player_id=nullif(trim(p_player_id),'') where id=p_user_id;
 if not found then raise exception 'Perfil no encontrado.'; end if;
end $$;
grant execute on function public.admin_edit_profile(uuid,text,text,text,text) to authenticated;

-- Bloquea la fila de escuadra mientras se comprueba el cupo para evitar equipos de más de 4.
create or replace function public.join_squad(p_code text) returns void
language plpgsql security definer set search_path=public as $$
declare sid uuid; n int;
begin
 if not public.is_member() then raise exception 'Solo miembros aceptados.'; end if;
 if exists(select 1 from public.squad_members where user_id=auth.uid()) then raise exception 'Ya perteneces a una escuadra.'; end if;
 select id into sid from public.squads where invite_code=upper(trim(p_code)) for update;
 if sid is null then raise exception 'Código incorrecto.'; end if;
 select count(*) into n from public.squad_members where squad_id=sid;
 if n>=4 then raise exception 'La escuadra está completa.'; end if;
 insert into public.squad_members(squad_id,user_id) values(sid,auth.uid());
end $$;
grant execute on function public.join_squad(text) to authenticated;

-- El PIN produce un token temporal vinculado a usuario; TODAS las acciones admin lo exigen.
create table if not exists public.admin_pin_sessions(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 token_hash text not null unique,
 expires_at timestamptz not null,
 created_at timestamptz not null default now()
);
alter table public.admin_pin_sessions enable row level security;
revoke all on public.admin_pin_sessions from anon,authenticated;
create or replace function public.has_valid_admin_pin(p_token text) returns boolean
language sql stable security definer set search_path=public as $$
 select auth.uid() is not null and public.has_admin_access() and exists(
  select 1 from public.admin_pin_sessions s where s.user_id=auth.uid()
   and s.token_hash=encode(digest(coalesce(p_token,''),'sha256'),'hex') and s.expires_at>now()
 )
$$;

-- Elimina las variantes antiguas que solo comprobaban el rol y no el PIN.
drop function if exists public.review_application(uuid,public.member_status);
drop function if exists public.set_member_role(uuid,public.clan_role);
drop function if exists public.admin_remove_squad_member(uuid,uuid);
drop function if exists public.admin_delete_squad(uuid);
drop function if exists public.admin_edit_profile(uuid,text,text,text,text);
drop policy if exists "application update admins" on public.applications;
revoke update on public.applications from authenticated;
drop policy if exists "chat moderate" on public.messages;
revoke delete on public.messages from authenticated;

create or replace function public.review_application(p_user_id uuid,p_status public.member_status,p_pin_token text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.has_valid_admin_pin(p_pin_token) then raise exception 'PIN administrativo vencido o inválido.'; end if;
 if p_status not in ('accepted','rejected') then raise exception 'Estado inválido.'; end if;
 update public.applications set status=p_status,reviewed_at=now() where user_id=p_user_id and status='pending';
 if not found then raise exception 'Solicitud no encontrada.'; end if;
 update public.profiles set status=p_status,joined_at=case when p_status='accepted' then now() else null end where id=p_user_id;
end $$;
create or replace function public.set_member_role(p_user_id uuid,p_role public.clan_role,p_pin_token text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.has_valid_admin_pin(p_pin_token) or not public.is_owner() then raise exception 'Se requiere owner y PIN válido.'; end if;
 if p_role not in ('member','admin') or p_user_id=auth.uid() then raise exception 'Cambio de rol no permitido.'; end if;
 update public.user_roles set role=p_role where user_id=p_user_id;
 if not found then raise exception 'Usuario no encontrado.'; end if;
end $$;
create or replace function public.admin_remove_squad_member(p_squad_id uuid,p_user_id uuid,p_pin_token text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.has_valid_admin_pin(p_pin_token) then raise exception 'PIN administrativo vencido o inválido.'; end if;
 delete from public.squad_members where squad_id=p_squad_id and user_id=p_user_id;
 if not found then raise exception 'Integrante no encontrado en esa escuadra.'; end if;
end $$;
create or replace function public.admin_delete_squad(p_squad_id uuid,p_pin_token text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.has_valid_admin_pin(p_pin_token) then raise exception 'PIN administrativo vencido o inválido.'; end if;
 delete from public.squads where id=p_squad_id;
 if not found then raise exception 'Escuadra no encontrada.'; end if;
end $$;
create or replace function public.admin_edit_profile(p_user_id uuid,p_username text,p_instagram text,p_clash text,p_player_id text,p_pin_token text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.has_valid_admin_pin(p_pin_token) then raise exception 'PIN administrativo vencido o inválido.'; end if;
 if char_length(trim(p_username))<3 or char_length(trim(p_username))>20 then raise exception 'El nombre debe tener entre 3 y 20 caracteres.'; end if;
 update public.profiles set username=trim(p_username),instagram=nullif(trim(p_instagram),''),clash=nullif(trim(p_clash),''),player_id=nullif(trim(p_player_id),'') where id=p_user_id;
 if not found then raise exception 'Perfil no encontrado.'; end if;
end $$;
create or replace function public.admin_delete_message(p_message_id uuid,p_pin_token text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.has_valid_admin_pin(p_pin_token) then raise exception 'PIN administrativo vencido o inválido.'; end if;
 delete from public.messages where id=p_message_id;
 if not found then raise exception 'Mensaje no encontrado.'; end if;
end $$;
grant execute on function public.review_application(uuid,public.member_status,text), public.set_member_role(uuid,public.clan_role,text), public.admin_remove_squad_member(uuid,uuid,text), public.admin_delete_squad(uuid,text), public.admin_edit_profile(uuid,text,text,text,text,text), public.admin_delete_message(uuid,text) to authenticated;
