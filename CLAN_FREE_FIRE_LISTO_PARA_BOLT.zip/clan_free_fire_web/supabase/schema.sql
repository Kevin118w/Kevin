-- Ejecutar en Supabase SQL Editor. Activa RLS y restringe las acciones por rol.
create extension if not exists pgcrypto;
create type public.member_status as enum ('applicant','pending','accepted','rejected');
create type public.clan_role as enum ('member','admin','owner');

create table public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 username text not null unique check (char_length(username) between 3 and 20),
 email text,
 avatar_url text,
 instagram text,
 clash text,
 player_id text,
 status public.member_status not null default 'applicant',
 joined_at timestamptz,
 created_at timestamptz not null default now()
);
create table public.user_roles(user_id uuid primary key references auth.users(id) on delete cascade, role public.clan_role not null default 'member');
create table public.applications(
 id uuid primary key default gen_random_uuid(), user_id uuid not null unique references auth.users(id) on delete cascade,
 game_name text not null, player_id text not null, rank text not null, reason text not null,
 status public.member_status not null default 'pending', created_at timestamptz not null default now(), reviewed_at timestamptz
);
create table public.squads(id uuid primary key default gen_random_uuid(), name text not null check(char_length(name) between 2 and 30), invite_code text not null unique, created_by uuid not null references auth.users(id), created_at timestamptz not null default now());
create table public.squad_members(squad_id uuid references public.squads(id) on delete cascade, user_id uuid unique references auth.users(id) on delete cascade, joined_at timestamptz not null default now(), primary key(squad_id,user_id));
create table public.messages(id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id), body text not null check(char_length(body) between 1 and 1000), created_at timestamptz not null default now());
create index messages_created_idx on public.messages(created_at);
create table public.chat_activity(user_id uuid primary key references auth.users(id) on delete cascade, seconds bigint not null default 0, updated_at timestamptz not null default now());
create table public.achievement_unlocks(user_id uuid references auth.users(id) on delete cascade, code text not null, unlocked_at timestamptz not null default now(), primary key(user_id,code));

create function public.is_member() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from profiles where id=auth.uid() and status='accepted')
$$;
create function public.has_admin_access() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from user_roles where user_id=auth.uid() and role in ('admin','owner'))
$$;
create function public.is_owner() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from user_roles where user_id=auth.uid() and role='owner')
$$;

create function public.on_user_created() returns trigger language plpgsql security definer set search_path=public as $$
declare nick text;
begin
 nick := coalesce(nullif(new.raw_user_meta_data->>'username',''), split_part(new.email,'@',1));
 insert into profiles(id,username,email) values(new.id,nick,new.email);
 insert into user_roles(user_id,role) values(new.id,'member');
 insert into chat_activity(user_id) values(new.id);
 insert into achievement_unlocks(user_id,code) values(new.id,'first_login') on conflict do nothing;
 return new;
exception when unique_violation then
 insert into profiles(id,username,email) values(new.id, nick||'_'||substr(new.id::text,1,4), new.email);
 insert into user_roles(user_id,role) values(new.id,'member');
 insert into chat_activity(user_id) values(new.id);
 insert into achievement_unlocks(user_id,code) values(new.id,'first_login') on conflict do nothing;
 return new;
end $$;
create trigger auth_user_created after insert on auth.users for each row execute procedure public.on_user_created();

-- Mantiene el username único y evita que el cliente cambie status/joined_at.
create function public.guard_profile_update() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is not null and not public.has_admin_access() then
   if new.status is distinct from old.status or new.joined_at is distinct from old.joined_at or new.id is distinct from old.id then raise exception 'No puedes modificar el estado del clan.'; end if;
 end if;
 return new;
end $$;
create trigger profile_guard before update on public.profiles for each row execute procedure public.guard_profile_update();

create function public.submit_application(p_game_name text,p_player_id text,p_rank text,p_reason text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is null then raise exception 'Inicia sesión.'; end if;
 if exists(select 1 from profiles where id=auth.uid() and status='accepted') then raise exception 'Ya eres miembro.'; end if;
 insert into applications(user_id,game_name,player_id,rank,reason,status)
 values(auth.uid(),p_game_name,p_player_id,p_rank,p_reason,'pending')
 on conflict(user_id) do update set game_name=excluded.game_name,player_id=excluded.player_id,rank=excluded.rank,reason=excluded.reason,status='pending',created_at=now(),reviewed_at=null;
 update profiles set status='pending',player_id=p_player_id where id=auth.uid();
end $$;

create function public.review_application(p_user_id uuid,p_status public.member_status) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.has_admin_access() then raise exception 'Sin permisos.'; end if;
 if p_status not in ('accepted','rejected') then raise exception 'Estado inválido.'; end if;
 update applications set status=p_status,reviewed_at=now() where user_id=p_user_id and status='pending';
 if not found then raise exception 'Solicitud no encontrada.'; end if;
 update profiles set status=p_status,joined_at=case when p_status='accepted' then now() else null end where id=p_user_id;
end $$;

create function public.set_member_role(p_user_id uuid,p_role public.clan_role) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.is_owner() then raise exception 'Solo el administrador principal puede cambiar roles.'; end if;
 if p_role='owner' then raise exception 'No se puede asignar otro propietario desde esta función.'; end if;
 if p_user_id=auth.uid() then raise exception 'No puedes cambiar tu propio rol.'; end if;
 update user_roles set role=p_role where user_id=p_user_id;
end $$;

create function public.create_squad(p_name text) returns public.squads
language plpgsql security definer set search_path=public as $$
declare result public.squads; code text;
begin
 if not public.is_member() then raise exception 'Solo miembros aceptados.'; end if;
 if exists(select 1 from squad_members where user_id=auth.uid()) then raise exception 'Ya perteneces a una escuadra.'; end if;
 code:=upper(encode(gen_random_bytes(4),'hex'));
 insert into squads(name,invite_code,created_by) values(p_name,code,auth.uid()) returning * into result;
 insert into squad_members(squad_id,user_id) values(result.id,auth.uid());
 return result;
end $$;
create function public.join_squad(p_code text) returns void language plpgsql security definer set search_path=public as $$
declare sid uuid; n int;
begin
 if not public.is_member() then raise exception 'Solo miembros aceptados.'; end if;
 if exists(select 1 from squad_members where user_id=auth.uid()) then raise exception 'Ya perteneces a una escuadra.'; end if;
 select id into sid from squads where invite_code=upper(trim(p_code));
 if sid is null then raise exception 'Código incorrecto.'; end if;
 select count(*) into n from squad_members where squad_id=sid;
 if n>=4 then raise exception 'La escuadra está completa.'; end if;
 insert into squad_members(squad_id,user_id) values(sid,auth.uid());
end $$;
create function public.leave_squad() returns void language plpgsql security definer set search_path=public as $$
begin delete from squad_members where user_id=auth.uid(); end $$;

create view public.achievements_view as
select p.id as user_id, a.code,
 case when a.code='first_login' then 1
      when a.code='clan_100d' then greatest(0,extract(epoch from (now()-coalesce(p.joined_at,now())))/86400)::int
      else coalesce(c.seconds,0)::numeric/3600 end as progress,
 case when a.code='first_login' then true
      when a.code='clan_100d' then p.joined_at is not null and now()-p.joined_at>interval '100 days'
      when a.code='chat_5h' then coalesce(c.seconds,0)>=18000
      when a.code='chat_10h' then coalesce(c.seconds,0)>=36000
      when a.code='chat_100h' then coalesce(c.seconds,0)>=360000 else false end as completed,
 u.unlocked_at
from profiles p cross join (values('first_login'),('chat_5h'),('chat_10h'),('chat_100h'),('clan_100d')) a(code)
left join chat_activity c on c.user_id=p.id left join achievement_unlocks u on u.user_id=p.id and u.code=a.code;

alter table profiles enable row level security; alter table user_roles enable row level security; alter table applications enable row level security; alter table squads enable row level security; alter table squad_members enable row level security; alter table messages enable row level security; alter table chat_activity enable row level security; alter table achievement_unlocks enable row level security;
create policy "profiles visible to clan" on profiles for select to authenticated using (id=auth.uid() or public.is_member() or public.has_admin_access());
create policy "own profile edit" on profiles for update to authenticated using(id=auth.uid() or public.has_admin_access()) with check(id=auth.uid() or public.has_admin_access());
create policy "roles readable to signed users" on user_roles for select to authenticated using(user_id=auth.uid() or public.is_owner() or public.has_admin_access());
create policy "applications own or admins read" on applications for select to authenticated using(user_id=auth.uid() or public.has_admin_access());
create policy "application submit own" on applications for insert to authenticated with check(user_id=auth.uid() and status='pending');
create policy "application update admins" on applications for update to authenticated using(public.has_admin_access()) with check(public.has_admin_access());
create policy "members read squads" on squads for select to authenticated using(public.is_member() or public.has_admin_access());
create policy "members read squad roster" on squad_members for select to authenticated using(public.is_member() or public.has_admin_access());
create policy "chat read members" on messages for select to authenticated using(public.is_member() or public.has_admin_access());
create policy "chat send members" on messages for insert to authenticated with check(user_id=auth.uid() and public.is_member());
create policy "chat moderate" on messages for delete to authenticated using(public.has_admin_access());
create policy "activity own read" on chat_activity for select to authenticated using(user_id=auth.uid() or public.has_admin_access());
create policy "unlocks own read" on achievement_unlocks for select to authenticated using(user_id=auth.uid() or public.has_admin_access());

grant usage on schema public to authenticated;
grant select,update on profiles to authenticated;
grant select on user_roles,applications,squads,squad_members,messages,chat_activity,achievement_unlocks,achievements_view to authenticated;
grant insert on applications,messages to authenticated;
grant delete on messages to authenticated;
grant execute on function public.submit_application(text,text,text,text), public.review_application(uuid,public.member_status), public.set_member_role(uuid,public.clan_role), public.create_squad(text), public.join_squad(text), public.leave_squad() to authenticated;
alter publication supabase_realtime add table public.messages;

-- IMPORTANTE: después de registrar tu cuenta, asigna el rol owner una sola vez
-- desde SQL Editor, sustituyendo el UUID por el id real de auth.users:
-- insert into public.user_roles(user_id,role) values('TU-UUID','owner')
-- on conflict(user_id) do update set role='owner';
