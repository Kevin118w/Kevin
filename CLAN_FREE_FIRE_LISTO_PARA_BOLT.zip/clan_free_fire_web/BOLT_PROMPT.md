# Instrucciones para Bolt.new — proyecto del clan Free Fire

Este proyecto es el sitio original del clan. **No lo reemplaces por una maqueta ni empieces desde cero.** Primero inspecciona todos los archivos y conserva el diseño rojo/negro/blanco, el contenido en español y las funciones ya implementadas.

## Objetivo

Convertir este proyecto en una aplicación web móvil y de escritorio realmente funcional, lista para probar y luego publicar en Bolt Hosting (`bolt.host`). Debe poder abrirse mediante un enlace HTTPS normal desde Chrome en Android, sin instalar APK.

## Reglas obligatorias

1. No dejes botones decorativos. Cada botón, formulario, pestaña y enlace debe ejecutar una acción real o estar claramente deshabilitado con una explicación.
2. No inventes resultados ni uses datos falsos como si fueran reales. Si falta una conexión, muestra un estado de configuración pendiente y explica qué falta.
3. No elimines características existentes para simplificar. Conserva y repara el proyecto actual.
4. No expongas secretos en el navegador, el repositorio ni archivos públicos. Nunca pongas una `service_role` key, contraseñas, hash/PIN administrativo ni tokens privados en `app.js` o en variables `VITE_*`.
5. No publiques automáticamente mientras queden errores o falten decisiones de configuración. Primero deja una versión de vista previa funcional y pide confirmación antes de publicar.
6. No afirmes que una función está probada si no la ejecutaste realmente.

## Funciones que debe tener

- Registro e inicio de sesión con correo y contraseña; persistencia de sesión; cierre de sesión; recuperación de contraseña; Google OAuth solo cuando esté configurado correctamente.
- Solicitud de reclutamiento obligatoria para nuevas cuentas. Los estados pendiente/rechazado no pueden entrar al área de miembros.
- Roles `owner`, `admin` y `member`, aplicados en servidor y no solo ocultando botones en la interfaz. El owner puede asignar/quitar admins; los admins pueden moderar según permisos.
- Perfil editable: nombre de usuario, URL de avatar, Instagram, cuenta de Clash, ID de jugador y fecha de ingreso.
- Panel de miembros.
- Escuadras de hasta cuatro integrantes, crear/unirse con código, salir de la propia escuadra y herramientas administrativas para expulsar o eliminar. Impedir que una persona esté en más de una escuadra y evitar que se supere el máximo incluso con dos uniones simultáneas.
- Chat del clan en tiempo real, historial persistente, presencia online y moderación administrativa.
- Logros y progreso guardados en servidor. No presentes el tiempo de pestaña abierta como prueba perfecta de actividad humana; explica que es una aproximación.
- Panel de administración con revisión de solicitudes, gestión de roles, miembros, escuadras y moderación del chat. El PIN administrativo debe validarse del lado servidor y no debe otorgar privilegios a una cuenta que no tenga rol autorizado.
- Interfaz adaptable a pantallas pequeñas, especialmente Android, con estados de carga, éxito y error comprensibles.

## Backend y datos

El proyecto incluye `supabase/schema.sql`, `supabase/migrations/20261108_hardening_and_features.sql` y `supabase/functions/verify-admin-pin/index.ts`.

1. Lee los tres archivos antes de modificar el backend.
2. Comprueba si es mejor conservar Supabase o migrar a Bolt Database. No migres automáticamente: primero explica ventajas, cambios y riesgos. Preferencia inicial: conservar el backend Supabase existente para no perder el diseño de seguridad y las funciones ya escritas.
3. Si conservas Supabase, ejecuta/valida el esquema y la migración en un proyecto de desarrollo, corrige errores SQL y prueba RLS con cuentas de distintos roles. Nunca asumas que el SQL ya fue aplicado.
4. Configura la Edge Function de verificación del PIN de forma segura. La `SUPABASE_SERVICE_ROLE_KEY` y `ADMIN_PIN_HASH` deben estar únicamente en secretos del servidor/Edge Function.
5. Usa solo la URL del proyecto y la clave pública `anon`/publishable en el cliente. Si se usa Bolt Database, recrea de forma segura tablas, políticas, autenticación y funciones equivalentes, y documenta cualquier diferencia antes de cambiar.
6. Revisa URLs de retorno de Auth, confirmación de correo, recuperación y Google OAuth. No declares Google login operativo hasta completar su configuración real.

## Revisión y pruebas antes de publicar

- Ejecuta el proyecto en la vista previa y corrige errores de consola, importaciones, rutas y compilación.
- Prueba en móvil y escritorio.
- Prueba con cuentas separadas: visitante, nuevo usuario, pendiente, aceptado, rechazado, admin y owner.
- Prueba registro, login, logout, recuperación, envío/revisión de solicitud, edición de perfil, creación/unión/salida de escuadra, límite de cuatro, chat entre dos sesiones, presencia, logros y acciones administrativas.
- Comprueba que un miembro normal no pueda llamar directamente a operaciones administrativas ni leer/modificar datos ajenos.
- Si una prueba requiere credenciales o configuración que no tienes, déjala marcada como pendiente; no la simules.
- Entrega un resumen de pruebas con: probado y correcto / corregido / pendiente de credenciales / pendiente de configuración.

## Publicación

Cuando la vista previa esté probada y el propietario lo autorice, publica en Bolt Hosting y entrega la URL pública HTTPS. Después actualiza las URLs permitidas de autenticación para que apunten al dominio publicado y vuelve a probar login y recuperación desde Chrome Android.

## Primera tarea

Antes de cambiar código, inspecciona el proyecto completo y responde con un plan corto: arquitectura actual, errores que encontraste, si puedes mantener Supabase, qué configuración falta y qué pruebas harás. Luego implementa los cambios necesarios sin convertirlo en una simple demostración visual.
