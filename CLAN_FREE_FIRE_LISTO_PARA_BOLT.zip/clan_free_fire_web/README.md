# Sitio web del clan Free Fire — versión de desarrollo

Sitio estático responsive en español. Se abre en Chrome Android, PC y tablet mediante una URL HTTPS pública cuando se publique en un hosting estático. No requiere APK. Incluye `manifest.webmanifest` y `sw.js` como opción de acceso tipo PWA; también funciona abriendo la URL normalmente en Chrome.

## Estado honesto

Esta versión corrige la navegación de registro/login y el acceso al panel admin; cambia las consultas para no depender de relaciones implícitas entre `auth.users` y `profiles`; agrega presencia realtime, registro de actividad con límite de tiempo en servidor, acciones de moderación de escuadras, endurecimiento de RLS y PIN con sesión autenticada. Se agregó configuración PWA opcional.

**Todavía no está publicada ni conectada a una base real.** No se ha podido probar contra un proyecto Supabase con credenciales reales, ni probar OAuth, emails, chat realtime o permisos con varias cuentas. La medición de actividad del chat es una aproximación de actividad con la pestaña visible/en foco y heartbeat; no puede demostrar que una persona esté escribiendo o conversando realmente. No la presentes como una medición infalible.

## 1. Crear el backend Supabase

1. Crea un proyecto en https://supabase.com.
2. En SQL Editor ejecuta primero `supabase/schema.sql` completo.
3. Ejecuta después `supabase/migrations/20261108_hardening_and_features.sql` completo.
4. En Project Settings → API copia Project URL y la clave `anon`/publishable. Nunca uses `service_role` en el navegador.
5. Pega esos dos valores en `SUPABASE_URL` y `SUPABASE_ANON_KEY` al principio de `app.js`.
6. En Authentication → URL Configuration configura los Redirect URLs de desarrollo y, más adelante, la URL pública HTTPS.
7. Si vas a ofrecer Google, habilita Google en Authentication → Providers y configura las credenciales OAuth y callback de Supabase. La opción Gmail significa inicio con Google; no se puede iniciar sesión con cualquier cuenta Gmail si OAuth no está configurado.
8. Configura SMTP en Supabase para confirmar correo y recuperar contraseña de forma fiable.

## 2. Crear el owner inicial

1. Registra tu cuenta desde la web.
2. En Supabase → Authentication → Users copia el UUID de esa cuenta.
3. En SQL Editor ejecuta, sustituyendo el UUID:

```sql
insert into public.user_roles(user_id, role)
values ('TU-UUID', 'owner')
on conflict (user_id) do update set role='owner';
```

4. Define un PIN de al menos 6 dígitos y calcula su SHA-256 en un entorno local confiable.
5. Instala Supabase CLI, inicia sesión y enlaza el proyecto. Configura secretos:

```bash
supabase secrets set ADMIN_PIN_HASH=HASH_SHA256
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=TU_SERVICE_ROLE_KEY
supabase functions deploy verify-admin-pin
```

La función requiere sesión JWT y comprueba que la cuenta ya tenga rol `admin` u `owner`; el PIN no concede roles. La Edge Function crea un token aleatorio vinculado a la cuenta y válido durante 30 minutos; las RPC administrativas lo exigen. La service_role key solo se guarda como secreto de la Edge Function y nunca en el navegador. El límite de intentos incluido en la Edge Function es por instancia y no sustituye un rate limit persistente a nivel de infraestructura.

## 3. Probar localmente

No abras `index.html` con `file://`: usa un servidor local, por ejemplo:

```bash
python -m http.server 8000
```

Abre `http://localhost:8000` en el navegador. Para probar Auth/OAuth, configura también las URLs de redirección en Supabase. Prueba con cuentas separadas: visitante, solicitud pendiente, miembro aceptado, admin y owner.

## 4. Publicar más adelante (NO se ha hecho)

Cuando decidas publicar, sube la carpeta a un repositorio y conéctala a un hosting estático como Vercel, Netlify o Cloudflare Pages. La raíz del proyecto es el directorio de publicación; no necesita proceso de build. Después agrega el dominio HTTPS a Supabase Auth → URL Configuration. Los usuarios podrán abrir el enlace directamente desde Chrome sin instalar nada. La PWA solo ofrece la opción de agregar un acceso directo; no es obligatoria.

## 5. Archivos importantes

- `index.html`, `styles.css`, `app.js`: interfaz y lógica de navegador.
- `supabase/schema.sql`: esquema inicial, funciones, vistas y RLS.
- `supabase/migrations/20261108_hardening_and_features.sql`: correcciones de privacidad, username, heartbeat y acciones administrativas.
- `supabase/functions/verify-admin-pin/index.ts`: validación del PIN ligada a JWT y rol existente.
- `manifest.webmanifest`, `sw.js`: metadatos y caché offline de la estructura estática.

## 6. Antes de usar con miembros reales

- Ejecutar ambos SQL en un proyecto Supabase nuevo y comprobar que terminan sin errores.
- Desplegar la Edge Function y configurar `ADMIN_PIN_HASH`.
- Configurar OAuth, SMTP y URLs permitidas.
- Probar políticas RLS y acciones con cuentas de diferentes roles.
- Revisar límites de mensajes, CAPTCHA/rate limits, backups y reglas de moderación.
- La presencia online usa Supabase Realtime Presence y depende de conexión; no es un registro histórico.
- El heartbeat solo acumula bloques de actividad cuando el navegador informa que la pestaña de chat está visible y enfocada. Un cliente modificado podría simularlo; para logros competitivos de alto valor se necesita un criterio de actividad más estricto.
- El nombre inicial del clan sigue como `CLAN FIRE`; se puede cambiar en `CLAN_NAME` de `app.js` y en los textos de `index.html`.
